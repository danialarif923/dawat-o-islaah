import{g as x,u as W,h as Y,i as G,k as J,r as d,j as e,U as X,l as Z,M as B,B as H,m as q,E as ee,z as c}from"./index-BG5kMDdU.js";import{h as te}from"./html2canvas.esm-5Cw11iw4.js";/**
 * @license lucide-react v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]],se=x("Calendar",re);/**
 * @license lucide-react v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],ne=x("ChevronDown",ae);/**
 * @license lucide-react v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oe=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],le=x("ChevronUp",oe);/**
 * @license lucide-react v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ie=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]],de=x("Clock",ie);/**
 * @license lucide-react v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]],I=x("Download",ce);/**
 * @license lucide-react v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xe=[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]],pe=x("Share2",xe),me=async(r,n="en")=>{var u,b,p;const k=`${(r.title||"question").toLowerCase().replace(/[^\w\s-]/g,"").trim().replace(/\s+/g,"-")||"question"}.png`,a=document.createElement("div");a.style.position="absolute",a.style.left="-9999px",a.style.top="-9999px",a.style.width="650px",a.style.padding="40px",a.style.backgroundColor="#0B131A",a.style.color="#FFFFFF",a.style.fontFamily=n==="ur"?"'Noto Nastaliq Urdu', serif":"'Merriweather', serif",a.style.borderRadius="16px",a.style.border="2px solid #233857",a.style.boxShadow="0 20px 25px -5px rgba(0, 0, 0, 0.3)",a.style.direction=n==="ur"?"rtl":"ltr";const f=`
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 25px;">
      <div style="display: flex; align-items: center; gap: 15px;">
        <img src="/assets/logo.jpeg" alt="Logo" style="width: 50px; height: 50px; border-radius: 8px; object-fit: cover; border: 1px solid #C9A227;" />
        <div>
          <h2 style="margin: 0; font-size: 20px; color: #C9A227; font-weight: bold;">Dawat o Islaah</h2>
          <span style="font-size: 11px; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.05em;">Islam Question & Answer</span>
        </div>
      </div>
      <div style="font-size: 12px; color: #C9A227; border: 1px solid #C9A227; padding: 4px 10px; border-radius: 20px;">
        ${((u=r.category)==null?void 0:u.name)||(n==="ur"?"فتویٰ":"Fatwa")}
      </div>
    </div>
    <div style="height: 2px; background: linear-gradient(to right, #C9A227, transparent); margin-bottom: 25px;"></div>
  `,j=`
    <div style="margin-bottom: 30px;">
      <div style="font-size: 12px; font-weight: bold; color: #029E65; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px;">
        ${n==="ur"?"سوال":"Question"}
      </div>
      <h1 style="margin: 0 0 12px 0; font-size: 24px; line-height: 1.4; color: #FFFFFF; font-weight: 700;">
        ${r.title}
      </h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.6; color: #D1D5DB; font-weight: normal; white-space: pre-wrap;">
        ${r.content||r.question}
      </p>
    </div>
  `,y=((b=r.answer)==null?void 0:b.content)||r.answer||"",N=`
    <div style="background-color: #132232; border-left: 4px solid #029E65; border-right: ${n==="ur"?"4px solid #029E65":"none"}; padding: 20px; border-radius: 8px; margin-bottom: 25px;">
      <div style="font-size: 12px; font-weight: bold; color: #029E65; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px;">
        ${n==="ur"?"جواب":"Answer"}
      </div>
      <p style="margin: 0; font-size: 15px; line-height: 1.7; color: #E5E7EB; white-space: pre-wrap;">
        ${y}
      </p>
      ${(p=r.answer)!=null&&p.mufti_name?`
        <div style="margin-top: 15px; font-size: 12px; color: #9CA3AF; text-align: ${n==="ur"?"left":"right"};">
          — ${n==="ur"?"مفتی":"Mufti"}: <strong>${r.answer.mufti_name}</strong>
        </div>
      `:""}
    </div>
  `,C=`
    <div style="text-align: center; font-size: 11px; color: #6B7280; margin-top: 30px; border-t: 1px solid #1E2D4A; padding-top: 15px;">
      ${n==="ur"?"مزید مستند اسلامی معلومات کے لیے ملاحظہ فرمائیں: dawatoislaah.com":"For more authentic Islamic information, visit dawatoislaah.com"}
    </div>
  `;a.innerHTML=`
    ${f}
    ${j}
    ${y?N:""}
    ${C}
  `,document.body.appendChild(a);try{const i=(await te(a,{backgroundColor:"#0B131A",useCORS:!0,scale:2,logging:!1,width:650,onclone:$=>{const A=$.getElementsByTagName("img");for(let h of A)h.style.display="block"}})).toDataURL("image/png"),l=document.createElement("a");l.href=i,l.download=k,document.body.appendChild(l),l.click(),document.body.removeChild(l)}catch(m){throw console.error("Screenshot capture failed:",m),m}finally{document.body.removeChild(a)}},fe=({question:r,index:n,highlightSearchTerm:v,onShare:k})=>{const{t:a,language:f}=W(),{trackView:j,toggleSave:y,trackDownload:N,getSavedList:C,postAnswer:u,qnaTheme:b}=Y(),{isAuthenticated:p}=G(),m=J(),[i,l]=d.useState(!1),[$,A]=d.useState(0),h=d.useRef(null),[E,S]=d.useState(!1),[g,z]=d.useState(""),[F,M]=d.useState(!1),s=f==="ur",L=String(n+1).padStart(2,"0"),w=C().includes(r.id),R=t=>{const o=new Date(t);return new Intl.DateTimeFormat(s?"ur-PK":"en-US",{year:"numeric",month:"short",day:"numeric"}).format(o)};d.useEffect(()=>{h.current&&A(i?h.current.scrollHeight:0)},[i,r.content]);const U=()=>{const t=!i;l(t),t&&j(r.id)},T=t=>{t.stopPropagation(),y(r.id),w?c.success(s?"محفوظ شدہ سوالات سے ہٹا دیا گیا!":"Removed from saved questions!"):c.success(s?"سوال محفوظ کر لیا گیا ہے!":"Question saved successfully!")},Q=async t=>{t.stopPropagation();try{await N(r.id),await me(r,f),c.success(s?"ڈاؤن لوڈ شروع ہو گیا ہے!":"Download started!")}catch(o){console.error(o),c.error(s?"ڈاؤن لوڈ ناکام ہو گیا!":"Download failed!")}},O=t=>{t.stopPropagation(),k(r)},V=t=>{if(t.stopPropagation(),!p){m("/signin");return}i||l(!0),S(!E)},K=async t=>{if(t.stopPropagation(),!!g.trim()){M(!0);try{await u(r.id,g),c.success(s?"آپ کا جواب مفتی صاحب کو بھیج دیا گیا ہے، منظوری کے بعد شائع کیا جائے گا!":"Your answer has been submitted to the Muftis. It will be published after approval."),z(""),S(!1)}catch{c.error(s?"جواب جمع کرنے میں ناکامی! براہ کرم دوبارہ کوشش کریں۔":"Failed to submit answer! Please try again.")}finally{M(!1)}}};return e.jsx("div",{onClick:U,className:"border rounded-2xl overflow-hidden transition-all duration-300 shadow-sm hover:shadow-md cursor-pointer theme-bg-card theme-border",style:b==="light"?{color:"#000"}:void 0,children:e.jsxs("div",{className:`p-5 sm:p-6 relative flex flex-col gap-3 ${s?"text-right":"text-left"}`,children:[e.jsxs("div",{className:`flex items-start justify-between w-full ${s?"flex-row-reverse":"flex-row"}`,children:[e.jsxs("div",{className:`flex items-center gap-3 ${s?"flex-row-reverse":"flex-row"}`,children:[e.jsx("span",{className:"text-2xl font-black text-black dark:text-[#233857] select-none leading-none",children:L}),e.jsx("span",{className:"px-2.5 py-1 text-xs font-bold uppercase tracking-wider rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 select-none",children:(()=>{const t=r.category,o=typeof t=="object"?t==null?void 0:t.name:null,_=typeof t=="object"?t==null?void 0:t.slug:null;if(_){const D="categories."+_,P=a(D);if(P!==D)return P}return o||a("categories.general")})()})]}),e.jsx("div",{className:"text-black dark:text-gray-400 hover:text-black dark:hover:text-white transition",children:i?e.jsx(le,{size:20}):e.jsx(ne,{size:20})})]}),e.jsx("h2",{className:"text-lg sm:text-xl font-bold text-black dark:text-white leading-snug mt-1",children:v?v(r.title):r.title}),e.jsx("div",{ref:h,className:"overflow-hidden transition-all duration-300 ease-in-out",style:{height:`${$}px`},children:e.jsxs("div",{className:"pt-2 pb-4 border-b border-gray-100 dark:border-[#233857]/50",children:[e.jsx("p",{className:"text-sm text-black dark:text-gray-100 leading-relaxed whitespace-pre-wrap",children:r.content||r.question}),r.answer&&(()=>{const t=r.answer,o=t.content||t;return(t.approval_status||"approved")==="pending"?e.jsx("div",{className:"mt-5 p-4 rounded-xl border border-amber-200 bg-amber-50 dark:border-amber-700/30 dark:bg-amber-900/10",children:e.jsxs("div",{className:"flex items-center gap-2 text-sm text-amber-700 dark:text-amber-300",children:[e.jsx(de,{size:16}),e.jsx("span",{className:"font-medium",children:s?"جواب زیرِ التواء منظوری ہے":"Answer pending approval"})]})}):e.jsxs("div",{className:"mt-5 p-4 rounded-xl border border-emerald-500/20 bg-emerald-500/5",children:[e.jsxs("h3",{className:"text-sm font-bold text-emerald-600 dark:text-emerald-400 mb-2 flex items-center gap-1.5 justify-start",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-emerald-500"}),s?"جواب:":"Answer:"]}),e.jsx("div",{className:"text-sm text-black dark:text-gray-100 leading-relaxed whitespace-pre-wrap",children:typeof o=="string"?o.replace(/<[^>]+>/g,""):""}),t.mufti_name&&e.jsxs("div",{className:"mt-3 flex items-center gap-1 text-xs text-black dark:text-gray-400 justify-start",children:[e.jsx(X,{size:12}),e.jsxs("span",{children:[s?"مفتی:":"Mufti:"," ",e.jsx("strong",{className:"font-semibold text-black dark:text-gray-300",children:t.mufti_name})]})]})]})})(),E&&e.jsxs("div",{className:"mt-4",onClick:t=>t.stopPropagation(),children:[e.jsx("textarea",{value:g,onChange:t=>z(t.target.value),rows:4,placeholder:s?"اپنا جواب یہاں لکھیں...":"Write your answer here...",className:"w-full border border-gray-200 dark:border-[#233857] rounded-xl px-4 py-3 bg-white dark:bg-[#0B131A] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm resize-none"}),e.jsxs("div",{className:"flex justify-end gap-2 mt-2",children:[e.jsx("button",{onClick:()=>{S(!1),z("")},className:"px-4 py-2 text-sm text-black dark:text-gray-400 hover:text-black dark:hover:text-white transition",children:s?"منسوخ کریں":"Cancel"}),e.jsxs("button",{onClick:K,disabled:F||!g.trim(),className:`px-4 py-2 text-sm font-medium rounded-lg transition flex items-center gap-1.5 ${F||!g.trim()?"bg-gray-300 text-gray-500 cursor-not-allowed":"bg-emerald-600 text-white hover:bg-emerald-700"}`,children:[F?e.jsx(Z,{size:14,className:"animate-spin"}):e.jsx(B,{size:14}),s?"جمع کریں":"Submit Answer"]})]})]})]})}),e.jsxs("div",{className:`flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-3 ${s?"sm:flex-row-reverse":""}`,children:[e.jsxs("div",{className:`flex items-center gap-4 text-xs font-semibold select-none ${s?"flex-row-reverse":"flex-row"}`,children:[e.jsxs("button",{onClick:T,className:`flex items-center gap-1.5 transition py-1 px-2.5 rounded-lg border cursor-pointer ${w?"bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400":"border-gray-200 dark:border-[#233857] text-black dark:text-gray-300 hover:text-black dark:hover:text-white"}`,children:[e.jsx(H,{size:15,fill:w?"currentColor":"none"}),e.jsx("span",{children:w?s?"محفوظ شدہ":"Saved":s?"محفوظ کریں":"Save"})]}),e.jsxs("button",{onClick:Q,className:"flex items-center gap-1.5 transition py-1 px-2.5 rounded-lg border border-gray-200 dark:border-[#233857] text-black dark:text-gray-300 hover:text-black dark:hover:text-white cursor-pointer",children:[e.jsx(I,{size:15}),e.jsx("span",{children:s?"ڈاؤن لوڈ":"Download"})]}),e.jsxs("button",{onClick:O,className:"flex items-center gap-1.5 transition py-1 px-2.5 rounded-lg border border-gray-200 dark:border-[#233857] text-black dark:text-gray-300 hover:text-black dark:hover:text-white cursor-pointer",children:[e.jsx(pe,{size:15}),e.jsx("span",{children:s?"شیئر کریں":"Share"})]}),e.jsxs("button",{onClick:V,className:"flex items-center gap-1.5 transition py-1 px-2.5 rounded-lg border border-gray-200 dark:border-[#233857] text-black dark:text-gray-300 hover:text-emerald-600 dark:hover:text-emerald-400 cursor-pointer",children:[p?e.jsx(B,{size:15}):e.jsx(q,{size:15}),e.jsx("span",{children:s?"جواب دیں":"Answer"})]})]}),e.jsx("div",{className:`flex items-center gap-4 text-xs text-black dark:text-gray-300 ${s?"flex-row-reverse":"flex-row"}`,children:e.jsxs("div",{className:`flex items-center gap-3 ${s?"flex-row-reverse":"flex-row"}`,children:[e.jsxs("span",{className:"flex items-center gap-1",title:"Views",children:[e.jsx(ee,{size:13}),e.jsx("span",{children:r.view_count||0})]}),e.jsxs("span",{className:"flex items-center gap-1",title:"Saves",children:[e.jsx(H,{size:13}),e.jsx("span",{children:r.saves_count??0})]}),e.jsxs("span",{className:"flex items-center gap-1",title:"Downloads",children:[e.jsx(I,{size:13}),e.jsx("span",{children:r.download_count||0})]})]})})]}),e.jsxs("div",{className:`flex items-center justify-center gap-1 text-xs text-black dark:text-gray-300 ${s?"flex-row-reverse":"flex-row"}`,children:[e.jsx(se,{size:13}),e.jsx("span",{children:R(r.created_at)})]})]})})};export{fe as default};
